//
//  DeletePatientModel.swift
//  MOCA
//
//  Created by AMAR on 16/11/23.
//

import Foundation

struct DeletePatientModel: Codable{
    let id,status,message: String
}

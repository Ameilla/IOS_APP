//
//  AddComment.swift
//  MOCA
//
//  Created by AMAR on 09/12/23.
//

import Foundation
struct AddComment: Codable {
    let status, message: String
}

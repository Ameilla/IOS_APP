//
//  ResultModel.swift
//  MOCA
//
//  Created by AMAR on 31/10/23.
//
//
//import UIKit
//
//class ResultModel: NSObject {
//
//}


import Foundation

// MARK: - Welcome
struct ResultModel: Codable {
    let status, message: String
}

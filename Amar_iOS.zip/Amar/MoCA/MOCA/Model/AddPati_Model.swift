//
//  AddPati_Model.swift
//  MOCA
//
//  Created by AMAR on 25/10/23.
//

//import Foundation
//
//// MARK: - Welcome
//struct AddPati_Model: Codable {
//    var status, message: String?
//}

import Foundation

// MARK: - Welcome
struct AddPati_Model:Codable{
    var status, message: String
}


//
//  Practicetable.swift
//  MOCA
//
//  Created by SAIL L1 on 07/10/23.
//

import UIKit

class Practicetable: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    let data=["Ame","Amar"	]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    

    }
}




